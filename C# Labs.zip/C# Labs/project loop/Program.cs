﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace project_loop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int no;
            float avg, tot = 0;
             

            for(int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Enter no{0}:", i);
                no = int.Parse(Console.ReadLine());
                tot = tot + no; ;
            }
            avg = tot / 10;
            Console.WriteLine("Avg is " + avg);
            Console.ReadKey();
        }
        
    }
}
