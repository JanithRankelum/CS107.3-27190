﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._06._21Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* declare a single dimensional array with 10 elements .Input the values to the array and find the followings
             1)minimum value
            2)maximum value
            3)average value
            4)reverse order of values
            hint-use a method which in seperate class .and call the method from main the method*/


            array objarray = new array();
            objarray.myarray();
            Console.ReadKey();
        }
    }
}
