﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labQ
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string a = takeName();
            Console.WriteLine(a);

            Console.ReadKey();

        }
        public static string takeName()
        {
            Console.WriteLine("Enter name:");
            string name = Console.ReadLine();

            return name;
        }
    }
}
