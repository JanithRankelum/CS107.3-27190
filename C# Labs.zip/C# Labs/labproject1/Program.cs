﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //write a consoele application to calculate the sum of two user input numbers
            /*int n1, n2;
            Console.WriteLine("Enter n1:");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter n2:");
            n2 = int.Parse(Console.ReadLine());
            double sum = n1 + n2;
            Console.WriteLine("Sum:" + sum);
            Console.ReadKey();*/
            double kilometer;
            Console.WriteLine("Enter Kilometer value:");
            kilometer = double.Parse(Console.ReadLine());
            double cm = kilometer * 10000;
           
            Console.WriteLine("CM:" + cm);
            Console.ReadKey();

        }
    }
}
