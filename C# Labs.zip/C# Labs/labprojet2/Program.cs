﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labprojet2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // write a console application to calculate sum,subsatraction, multiplication and division of two user input numbers
            double n1, n2;
            Console.WriteLine("Enter n1:");
            n1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter n2:");
            n2 = double.Parse(Console.ReadLine());
            double sum = n1 + n2;
            double sub = n1 - n2;
            double mul = n1 * n2;
            double div = n1 / n2;
            Console.WriteLine("Sum:" + sum);
            Console.WriteLine("Sub:" + sub);
            Console.WriteLine("Mul:" + mul);
            Console.WriteLine("Div:" + div);
            Console.ReadKey();

                
        }
    }
}
