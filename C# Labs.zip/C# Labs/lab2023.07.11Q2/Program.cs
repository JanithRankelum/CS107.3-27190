﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._07._11Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Question 02

Create a Console application program which contain an encapsulation class for four basic arithmetic Operations

Inside the encapsulation class you should have two private variables and getters and setters for basic authmetic operations. 
Then return answers for summation, subtraction, multiplication and don and print them on main method*/
        }
    }
}
