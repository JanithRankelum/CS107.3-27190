﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._06._23Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Declare two single dimensional array with the size given by the user and find, display the followings;
Scalar Sum (Adding values of each element of an array)
Vector Sum (Adding values of each relative elements of an array and store them in third array)
Vector Product (Multiply values of each relative elements of an array and store them in third array)
Scalar Product (Multiply values of each relative elements of an array and store them in third array. 
            After placing the values in third array add all the values)*/


            Console.Write("Enter the size of the arrays: ");
            int size = int.Parse(Console.ReadLine());

            int[] array1 = new int[size];
            int[] array2 = new int[size];
            int[] resultArray = new int[size];

            Console.WriteLine("Enter values for Array 1:");
            for (int i = 0; i < size; i++)
            {
                Console.Write($"Enter value for element {i + 1}: ");
                array1[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Enter values for Array 2:");
            for (int i = 0; i < size; i++)
            {
                Console.Write($"Enter value for element {i + 1}: ");
                array2[i] = int.Parse(Console.ReadLine());
            }

            // Scalar Sum
            int scalarSum = 0;
            for (int i = 0; i < size; i++)
            {
                scalarSum += array1[i] + array2[i];
            }
            Console.WriteLine("Scalar Sum: " + scalarSum);

            // Vector Sum
            Console.WriteLine("Vector Sum:");
            for (int i = 0; i < size; i++)
            {
                resultArray[i] = array1[i] + array2[i];
                Console.Write(resultArray[i] + " ");
            }
            Console.WriteLine();

            // Vector Product
            Console.WriteLine("Vector Product:");
            for (int i = 0; i < size; i++)
            {
                resultArray[i] = array1[i] * array2[i];
                Console.Write(resultArray[i] + " ");
            }
            Console.WriteLine();

            // Scalar Product and Sum
            int scalarProductSum = 0;
            for (int i = 0; i < size; i++)
            {
                resultArray[i] = array1[i] * array2[i];
                scalarProductSum += resultArray[i];
            }
            Console.WriteLine("Scalar Product Sum: " + scalarProductSum);

            Console.ReadLine();
        }
    }
}
    

