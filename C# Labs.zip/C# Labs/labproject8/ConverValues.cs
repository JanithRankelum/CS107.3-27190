﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject8
{
    internal class ConverValues
    {
        public void kilometerTometer(double km)
        {
            double m = km * 1000;
            Console.WriteLine("Meter:" + m);
        }
            
    }
}
