﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject9
{
    internal class ConvertValues
    {
        public double kilometerTometer(double km)
        {
            double m = km * 1000;
            return m;
        }
    }
}
