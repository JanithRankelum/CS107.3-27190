﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject6
{
    public class ConverValues
    {
        public void kilometerTometer(float kilometer)//if we don't have return type .we using void, public we can use in every class
        {
            
            float meters = kilometer * 1000;
            Console.WriteLine("{0} kilometers is equal to {0} meters", kilometer, meters);
            Console.ReadKey();

        }
    }
}
