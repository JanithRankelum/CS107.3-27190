﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Create a C# console application to convert user given kilo meter value to meter value. Take a seperte class call "Convert values" and 
            inside   class create a method call kolimeterToMeter.(No return type no parameter method). And display the answer within the method.
            Then create an object in main class (program class ) and call the method.*/
            Console.WriteLine("Enter the kilometer value:");
            float K = float.Parse(Console.ReadLine());
            kilometerTometer(float kilometer);
            Console.ReadKey();

        }
    }
    

}
