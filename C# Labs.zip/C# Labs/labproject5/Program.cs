﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //get 10 numbers and display the even or odd for each user

            int n;
            for (int i = 1; i <= 10; i++)
            {
                Console.Write("Enter no " + i + ":");
                n = int.Parse(Console.ReadLine());
                
            }
            for (int i = 1; i <= 10; i++)
            {
                if (n % 2 == 0)
                {
                    Console.WriteLine("{0} is even", n);
                }
                else
                {
                    Console.WriteLine("{0} is odd", n);
                }
            }


            Console.ReadKey();
        }
    }
}
