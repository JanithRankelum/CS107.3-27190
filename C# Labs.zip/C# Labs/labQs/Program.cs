﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labQs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //get users name and age as inputs (inside the main) then print using new function call "print details"
            string name,age;
            
            Console.WriteLine("Enter your name:");
            name = Console.ReadLine();
            Console.WriteLine("Enter your age:");
            age = Console.ReadLine();

            printdetails(name, age);
            ;
            Console.ReadKey();

        }
        public static void printdetails(string name, string age)
            {
            Console.WriteLine("Name:" + name);
            Console.WriteLine("Age:" + age);
            

}

    }
}
