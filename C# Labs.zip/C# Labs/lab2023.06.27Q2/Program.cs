﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._06._27Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Create a C# program that can find minimum and maximum from a given Single Dimensional Array*/

            array objarray = new array();
            objarray.method();

            Console.ReadKey();
        }
    }
}
