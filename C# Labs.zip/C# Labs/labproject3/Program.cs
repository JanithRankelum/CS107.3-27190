﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // write a console application to calculate the area and the circumference for the given radius
            //double r;
            Console.WriteLine("Enter the radius:");
            double r = double.Parse(Console.ReadLine());
            double circum = 2 * Math.PI * r;
            double area = Math.PI*r*r;
            Console.WriteLine("Circumference:" + circum);
            Console.WriteLine("Area:" + area);
            Console.ReadKey();
        }
    }
}
