﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._06._27Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*1. Create a C# Console Application which can get the scalar/linear summation of an array with 10 elements. Ask the user to 
             enter the values for the array.*/

            array objarray = new array();
            objarray.method();

            Console.ReadKey();
        }
    }
}
