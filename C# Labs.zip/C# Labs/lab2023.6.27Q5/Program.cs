﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._6._27Q5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Create a C# program that can multiply two 2x2 Matrices.*/
            int[,] arr = new int[2, 2] { { 1, 9 }, { 2, 6 } };
        }
    }
}
