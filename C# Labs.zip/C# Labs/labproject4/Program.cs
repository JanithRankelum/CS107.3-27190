﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labproject4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //write a console apllication to check if a given number is even or odd
            int n1;
            Console.WriteLine("Enter n1:");
            n1 = int.Parse(Console.ReadLine());
            if (n1%2== 0)
            {
                Console.WriteLine("{0} is even", n1);
            }
            else
                Console.WriteLine("{0} is odd", n1);
            Console.ReadKey();
        }
    }
}
