﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2023._06._21Q1
{
    internal class hello
    {
        private void sayHello()
        {
            Console.WriteLine("Hello world!");
        }
    }
}
