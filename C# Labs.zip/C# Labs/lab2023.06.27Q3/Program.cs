﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._06._27Q3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Create a C# program that can sort a Single dimensional array according to ascending and descending order*/

            array objarray = new array();
            objarray.method();

            Console.ReadKey();


        }
    }
}
