﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labQ2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //get 2 user inputs(inside main) then get sum and return in fuction call 'get sum' (print inside the main)
            int no1, no2;
            Console.Write("Enter no1:");
            no1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter no2:");
            no2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Ans is :" + getsum(no1, no2));
)
            getsum(no1, no2);
            Console.ReadKey();

        }
        public static int getsum(int no1,int no2)
        {
            int sum = no1 + no2;
            return sum;
        }
    }
}
