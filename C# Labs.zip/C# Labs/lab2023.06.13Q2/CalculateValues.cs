﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2023._06._13Q2
{
    internal class CalculateValues
    {
        public double add(double n1,double n2)
        {
            double addition = n1 + n2;
            return addition;
        }
        public double sub(double n1,double n2)
        {
            double substraction = n1 - n2;
            return substraction;
        }
        public double mul(double n1,double n2)
        {
            double multiplication = n1 * n2;
            return multiplication;

        }
        public double div(double n1, double n2)
        {
            double division = n1 / n2;
            return division;

        }


    }
}
